def get_file_extension(filename):
    """Get the file extension from a filename"""
    return filename.split('.')[-1].lower()

def is_valid_file_type(uploaded_file):
    """Check if the uploaded file has a valid type"""
    valid_extensions = ['jpg', 'jpeg', 'png', 'pdf', 'docx']
    file_extension = get_file_extension(uploaded_file.name)
    return file_extension in valid_extensions

def get_document_type_icon(file_extension):
    """Get an appropriate icon HTML for a document type"""
    file_extension = file_extension.lower()
    
    if file_extension in ['jpg', 'jpeg', 'png']:
        return '<i class="fas fa-file-image" style="font-size: 5em; color: #4CAF50;"></i>'
    elif file_extension == 'pdf':
        return '<i class="fas fa-file-pdf" style="font-size: 5em; color: #F44336;"></i>'
    elif file_extension == 'docx':
        return '<i class="fas fa-file-word" style="font-size: 5em; color: #2196F3;"></i>'
    else:
        return '<i class="fas fa-file" style="font-size: 5em; color: #9E9E9E;"></i>'
