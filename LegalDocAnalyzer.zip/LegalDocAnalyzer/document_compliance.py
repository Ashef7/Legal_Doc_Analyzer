
def analyze_compliance(text):
    """
    Analyze extracted text for basic compliance issues in Indian legal documents.
    
    Returns a list of issues with category, description, affected text, and recommendation.
    """
    issues = []
    text_lower = text.lower()
    
    # Check for common missing elements
    if "date" not in text_lower:
        issues.append({
            "category": "Missing Date",
            "description": "The document does not mention a valid date.",
            "text": "[No date found]",
            "recommendation": "Include the date of execution or verification in the document."
        })
    
    if "signature" not in text_lower:
        issues.append({
            "category": "Signature Verification",
            "description": "The document lacks any mention of a signature.",
            "text": "[No signature found]",
            "recommendation": "Ensure the document is signed by the relevant authority or parties."
        })

    if "name" not in text_lower or "party" not in text_lower:
        issues.append({
            "category": "Missing Party Information",
            "description": "The document does not clearly mention the involved parties or names.",
            "text": "[Missing party details]",
            "recommendation": "Add names and roles of all parties involved."
        })

    if "stamp" not in text_lower and "seal" not in text_lower:
        issues.append({
            "category": "Missing Official Mark",
            "description": "No reference to official stamps or seals.",
            "text": "[No stamp or seal found]",
            "recommendation": "Affix an official stamp or seal to validate the document."
        })

    return issues
