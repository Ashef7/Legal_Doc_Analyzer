# Indian Legal Document Analyzer

A Streamlit-based application for analyzing and classifying Indian legal documents.

## Features

- Upload and analyze various document formats (JPEG, PNG, PDF, DOCX)
- Extract text using OCR and document parsing
- Classify documents based on Indian legal documentation standards
- Store analysis history in a database
- View statistics and trends of analyzed documents

## Requirements

### System Dependencies

- Python 3.7+
- Tesseract OCR engine
- Poppler (for PDF processing)

### Python Dependencies

The project requires the following Python packages:

