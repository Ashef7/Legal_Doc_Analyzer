import os
from sqlalchemy import create_engine, Column, Integer, String, Boolean, Float, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class Document(Base):
    __tablename__ = 'documents'
    
    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)
    file_type = Column(String(10), nullable=False)
    extracted_text = Column(Text, nullable=True)
    is_legal = Column(Boolean, default=False)
    confidence = Column(Float, default=0.0)
    criteria_results = Column(Text, nullable=True)
    upload_time = Column(DateTime, nullable=False)

def get_database_url():
    """Get database URL from environment variable or use SQLite as fallback"""
    db_url = os.getenv("DATABASE_URL")
    
    if db_url and db_url.startswith("postgres://"):
        # Heroku postgres URL fix
        db_url = db_url.replace("postgres://", "postgresql://", 1)
    
    # If no DATABASE_URL is provided, use SQLite
    if not db_url:
        db_url = "sqlite:///document_analyzer.db"
    
    return db_url

def init_db():
    """Initialize the database with required tables"""
    engine = create_engine(get_database_url())
    Base.metadata.create_all(engine)
    return engine

def get_session():
    """Get a database session"""
    engine = create_engine(get_database_url())
    Session = sessionmaker(bind=engine)
    return Session()
