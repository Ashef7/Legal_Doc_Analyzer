import os
import pytesseract
import docx
from pdf2image import convert_from_path
from PIL import Image
import tempfile

def extract_text_from_image(image_path):
    """Extract text from an image using pytesseract OCR"""
    try:
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image)
        return text
    except Exception as e:
        print(f"Error extracting text from image: {str(e)}")
        return ""

def extract_text_from_pdf(pdf_path):
    """Extract text from a PDF file using pdf2image and pytesseract"""
    try:
        # Create a temporary directory to store the images
        with tempfile.TemporaryDirectory() as temp_dir:
            # Convert PDF to images
            images = convert_from_path(pdf_path, output_folder=temp_dir)
            
            # Extract text from each image
            text = ""
            for i, image in enumerate(images):
                image_path = f"{temp_dir}/page_{i+1}.jpg"
                image.save(image_path, "JPEG")
                text += extract_text_from_image(image_path)
                text += "\n\n"  # Add separation between pages
            
            return text
    except Exception as e:
        print(f"Error extracting text from PDF: {str(e)}")
        return ""

def extract_text_from_docx(docx_path):
    """Extract text from a DOCX file using python-docx"""
    try:
        doc = docx.Document(docx_path)
        text = ""
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
        
        # Also extract text from tables
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    text += cell.text + "\t"
                text += "\n"
        
        return text
    except Exception as e:
        print(f"Error extracting text from DOCX: {str(e)}")
        return ""

def extract_text_from_file(file_path, file_extension):
    """Extract text from a file based on its extension"""
    file_extension = file_extension.lower()
    
    if file_extension in ['jpg', 'jpeg', 'png']:
        return extract_text_from_image(file_path)
    elif file_extension == 'pdf':
        return extract_text_from_pdf(file_path)
    elif file_extension == 'docx':
        return extract_text_from_docx(file_path)
    else:
        return "Unsupported file type"
