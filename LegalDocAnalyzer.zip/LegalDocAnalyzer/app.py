import streamlit as st
import os
import tempfile
import time
import pandas as pd
import base64
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go

# Import custom modules
from document_analyzer import extract_text_from_file
from document_classifier import classify_document
from database import init_db, Document, get_session
from utils import get_file_extension, is_valid_file_type, get_document_type_icon

# Configure Streamlit page
st.set_page_config(
    page_title="Indian Legal Document Analyzer",
    page_icon="📜",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize database
init_db()

# Define function to save uploaded file
def save_uploaded_file(uploaded_file):
    temp_dir = tempfile.mkdtemp()
    temp_path = os.path.join(temp_dir, uploaded_file.name)
    
    with open(temp_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    return temp_path

# Function to generate download link
def get_download_link(file_path, file_name):
    with open(file_path, "rb") as file:
        contents = file.read()
    
    b64 = base64.b64encode(contents).decode()
    return f'<a href="data:application/octet-stream;base64,{b64}" download="{file_name}">Download File</a>'

# Sidebar with native Streamlit components
st.sidebar.title("Indian Legal Document Analyzer")

# Add an image 
st.sidebar.image("https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg", width=120, use_container_width=False)

# About section with native Streamlit components
st.sidebar.subheader("ℹ️ About This Tool")
st.sidebar.info(
    "This intelligent system analyzes and classifies documents based on Indian legal standards. "
    "Upload your documents and get instant verification results with detailed analysis."
)

# Add a divider
st.sidebar.markdown("---")

# Supported Formats with columns
st.sidebar.subheader("📄 Supported Formats")
col1, col2 = st.sidebar.columns(2)
with col1:
    st.markdown("**Images**")
    st.markdown("JPG, PNG")
with col2:
    st.markdown("**Documents**")
    st.markdown("DOCX, PDF")

# Verification criteria
st.sidebar.subheader("🔍 Verification Criteria")
criteria_expander = st.sidebar.expander("View all criteria", expanded=False)
with criteria_expander:
    st.markdown("- **Government ID Documents**")
    st.markdown("  - Aadhar Card Format")
    st.markdown("  - PAN Card Format")
    st.markdown("- **Official Documents**")
    st.markdown("  - Government Headers")
    st.markdown("  - Official Letterhead")
    st.markdown("  - Document Reference Numbers")
    st.markdown("- **Legal Documents**")
    st.markdown("  - Legal Terminology")
    st.markdown("  - Digital Signature References")
    st.markdown("  - Standard Date Formats")

# Add How It Works section with native Streamlit components
st.sidebar.subheader("📝 How It Works")
how_it_works_expander = st.sidebar.expander("View process", expanded=True)
with how_it_works_expander:
    col1, col2 = st.columns([1, 5])
    with col1:
        st.markdown("**1.**")
    with col2:
        st.markdown("Upload your document (JPG, PNG, DOCX, PDF)")
    
    col1, col2 = st.columns([1, 5])
    with col1:
        st.markdown("**2.**")
    with col2:
        st.markdown("AI extracts text using OCR technology")
    
    col1, col2 = st.columns([1, 5])
    with col1:
        st.markdown("**3.**")
    with col2:
        st.markdown("Document is analyzed against legal criteria")
    
    col1, col2 = st.columns([1, 5])
    with col1:
        st.markdown("**4.**")
    with col2:
        st.markdown("Get verification results and confidence score")

# Add Document Types section
st.sidebar.subheader("📋 Document Types")
doc_types_expander = st.sidebar.expander("View document types", expanded=False)
with doc_types_expander:
    st.markdown("- Government IDs (Aadhar, PAN)")
    st.markdown("- Official documents with letterheads")
    st.markdown("- Legal contracts and agreements")
    st.markdown("- Court documents and notices")
    st.markdown("- Government issued certificates")
    st.markdown("- Official correspondence")
    st.markdown("- Other documents with legal elements")

# Create tabs
tab1, tab2, tab3 = st.tabs(["Document Analyzer", "History", "Statistics"])

# Tab 1: Document Analyzer
with tab1:
    st.markdown("<h1 class='main-header'>Indian Legal Document Analyzer</h1>", unsafe_allow_html=True)
    st.markdown("<h2 class='sub-header'>Upload & Verify Documents</h2>", unsafe_allow_html=True)
    
    # Upload box
    st.markdown("<div class='info-box'>", unsafe_allow_html=True)
    st.write("Upload a document to analyze and classify it according to Indian legal standards. The system will extract text, analyze its content, and determine if it appears to be a legal document.")
    st.markdown("</div>", unsafe_allow_html=True)
    
    upload_col1, upload_col2 = st.columns([2, 1])
    
    with upload_col1:
        uploaded_file = st.file_uploader("Choose a file (JPEG, PNG, PDF, DOCX)", type=["jpg", "jpeg", "png", "pdf", "docx"], label_visibility="collapsed")
    
    with upload_col2:
        st.markdown("<br>", unsafe_allow_html=True)
        analyze_button = st.button("Analyze Document", use_container_width=True)
    
    if uploaded_file is not None and analyze_button:
        if not is_valid_file_type(uploaded_file):
            st.error("Invalid file type. Please upload a JPEG, PNG, PDF, or DOCX file.")
        else:
            # Create a session
            session = get_session()
            
            # Save uploaded file
            temp_path = save_uploaded_file(uploaded_file)
            
            # Show processing status
            st.markdown("<h3 class='sub-header'>Document Analysis</h3>", unsafe_allow_html=True)
            
            # Progress bar for extraction
            progress_bar = st.progress(0)
            st.markdown("**Processing document...**")
            
            # Simulate processing steps with progress
            for i in range(101):
                if i < 30:
                    status_text = "Uploading document..."
                elif i < 60:
                    status_text = "Extracting text from document..."
                elif i < 90:
                    status_text = "Analyzing content against legal criteria..."
                else:
                    status_text = "Finalizing results..."
                
                progress_bar.progress(i)
                if i % 10 == 0:
                    st.markdown(f"**{status_text}**")
                    time.sleep(0.01)
            
            progress_bar.progress(100)
            
            # Success animation
            st.success("Analysis Complete!")
            time.sleep(0.5)
        
            # Remove progress elements
            progress_bar.empty()
            
            # Extract text and classify
            try:
                file_extension = get_file_extension(uploaded_file.name)
                extracted_text = extract_text_from_file(temp_path, file_extension)
                
                # Classify document based on extracted text
                is_legal, confidence, criteria_results = classify_document(extracted_text)
                
                # Store in database
                doc = Document(
                    filename=uploaded_file.name,
                    file_type=file_extension.upper(),
                    extracted_text=extracted_text,
                    is_legal=is_legal,
                    confidence=confidence * 100,  # Convert to percentage
                    criteria_results=str(criteria_results),
                    upload_time=datetime.now()
                )
                
                session.add(doc)
                session.commit()
                
                # Display results with styling
                st.markdown("<h3 class='sub-header'>Verification Results</h3>", unsafe_allow_html=True)
                
                # Enhanced colorful metrics based on legality with animations and improved design
                if is_legal:
                    st.success(f"""
                    ### LEGAL DOCUMENT
                    **Confidence:** {confidence:.1f}%
                    
                    This document meets the required legal standards based on our analysis criteria.
                    """)
                else:
                    st.error(f"""
                    ### NON-COMPLIANT DOCUMENT
                    **Confidence:** {confidence:.1f}%
                    
                    This document does not meet enough legal criteria based on our analysis.
                    See the verification details below.
                    """)
                
                # Enhanced criteria interpretation
                criteria_met = sum(1 for result in criteria_results.values() if result)
                total_criteria = len(criteria_results)
                
                st.markdown("<h3 class='sub-header'>Verification Details</h3>", unsafe_allow_html=True)
                
                # Create two columns for better layout
                col1, col2 = st.columns(2)
                
                with col1:
                    # Display document information
                    st.markdown("##### Document Information")
                    st.markdown(f"**Filename:** {uploaded_file.name}")
                    st.markdown(f"**File Type:** {file_extension.upper()}")
                    st.markdown(f"**Upload Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                    
                    # Display criteria verification status
                    st.markdown("##### Verification Criteria")
                    
                    # Categorize criteria by type
                    gov_id_criteria = {k: v for k, v in criteria_results.items() if "Aadhar" in k or "PAN" in k}
                    official_doc_criteria = {k: v for k, v in criteria_results.items() if "Official" in k or "Header" in k or "Letterhead" in k or "Document Number" in k}
                    legal_doc_criteria = {k: v for k, v in criteria_results.items() if "Legal" in k or "Digital" in k or "Date" in k}
                    
                    # Show categorized criteria
                    with st.expander("Government ID Criteria", expanded=True):
                        for criterion, is_met in gov_id_criteria.items():
                            status = "✅ Passed" if is_met else "❌ Failed"
                            st.markdown(f"- {criterion}: {status}")
                    
                    with st.expander("Official Document Criteria", expanded=True):
                        for criterion, is_met in official_doc_criteria.items():
                            status = "✅ Passed" if is_met else "❌ Failed"
                            st.markdown(f"- {criterion}: {status}")
                    
                    with st.expander("Legal Document Criteria", expanded=True):
                        for criterion, is_met in legal_doc_criteria.items():
                            status = "✅ Passed" if is_met else "❌ Failed"
                            st.markdown(f"- {criterion}: {status}")
                
                with col2:
                    # Show verification summary
                    st.markdown("##### Verification Summary")
                    st.markdown(f"**Overall Status:** {'Legal Document' if is_legal else 'Non-Compliant Document'}")
                    st.markdown(f"**Confidence Score:** {confidence:.1f}%")
                    st.markdown(f"**Criteria Met:** {criteria_met} of {total_criteria}")
                    
                    # Display criteria results as a gauge chart
                    fig = go.Figure(go.Indicator(
                        mode="gauge+number",
                        value=criteria_met,
                        domain={'x': [0, 1], 'y': [0, 1]},
                        title={'text': "Criteria Met", 'font': {'size': 24, 'color': '#3B82F6'}},
                        gauge={
                            'axis': {'range': [0, total_criteria], 'tickwidth': 1, 'tickcolor': "#3B82F6"},
                            'bar': {'color': "#3B82F6" if is_legal else "#EF4444"},
                            'bgcolor': "white",
                            'borderwidth': 2,
                            'bordercolor': "#E2E8F0",
                            'steps': [
                                {'range': [0, total_criteria/3], 'color': '#FEE2E2'},
                                {'range': [total_criteria/3, 2*total_criteria/3], 'color': '#FEF3C7'},
                                {'range': [2*total_criteria/3, total_criteria], 'color': '#DCFCE7'}
                            ],
                            'threshold': {
                                'line': {'color': "green", 'width': 4},
                                'thickness': 0.75,
                                'value': total_criteria/2
                            }
                        }
                    ))
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # View extracted text
                    st.markdown("**Extracted Text:**")
                    st.text_area("", extracted_text, height=150, key=f"text_area_{time.time()}")
                
            except Exception as e:
                st.error(f"Error processing document: {str(e)}")
                st.exception(e)
            
            finally:
                # Close the session
                session.close()

# Tab 2: History
with tab2:
    st.markdown("<h1 class='main-header'>Document History</h1>", unsafe_allow_html=True)
    st.markdown("<h2 class='sub-header'>Previously Analyzed Documents</h2>", unsafe_allow_html=True)
    
    # Create a session for history
    history_session = get_session()
    
    # Retrieve historical records
    try:
        # Get all documents
        documents = history_session.query(Document).order_by(Document.upload_time.desc()).all()
        
        if not documents:
            st.info("No documents have been analyzed yet. Upload a document in the Analyzer tab to get started.")
        else:
            # Create DataFrame for display
            history_data = []
            for doc in documents:
                history_data.append({
                    "ID": doc.id,
                    "Filename": doc.filename,
                    "Type": doc.file_type,
                    "Is Legal": "✅ Yes" if doc.is_legal else "❌ No",
                    "Confidence": f"{doc.confidence:.1f}%",
                    "Upload Time": doc.upload_time.strftime("%Y-%m-%d %H:%M")
                })
            
            history_df = pd.DataFrame(history_data)
            
            # Add filters
            filter_col1, filter_col2, filter_col3 = st.columns(3)
            with filter_col1:
                legal_filter = st.selectbox("Legal Status", ["All", "Legal", "Non-Legal"])
            
            with filter_col2:
                type_filter = st.selectbox("Document Type", ["All"] + list(set(doc.file_type for doc in documents)))
            
            with filter_col3:
                date_filter = st.date_input("From Date", value=None)
            
            # Apply filters
            filtered_df = history_df.copy()
            
            if legal_filter != "All":
                filter_value = "✅ Yes" if legal_filter == "Legal" else "❌ No"
                filtered_df = filtered_df[filtered_df["Is Legal"] == filter_value]
            
            if type_filter != "All":
                filtered_df = filtered_df[filtered_df["Type"] == type_filter]
            
            if date_filter:
                date_str = date_filter.strftime("%Y-%m-%d")
                filtered_df = filtered_df[filtered_df["Upload Time"].str.startswith(date_str)]
            
            # Display filtered results
            st.dataframe(filtered_df, use_container_width=True)
            
            # Document details view
            st.markdown("<h3 class='sub-header'>Document Details</h3>", unsafe_allow_html=True)
            
            if not filtered_df.empty:
                selected_id = st.selectbox("Select a document to view details:", filtered_df["ID"].tolist())
                
                if selected_id:
                    selected_doc = next((doc for doc in documents if doc.id == selected_id), None)
                    
                    if selected_doc:
                        # Display document details in a card layout
                        st.markdown("#### Document Information")
                        
                        detail_col1, detail_col2 = st.columns(2)
                        
                        with detail_col1:
                            st.markdown(f"**Filename:** {selected_doc.filename}")
                            st.markdown(f"**File Type:** {selected_doc.file_type}")
                            st.markdown(f"**Upload Time:** {selected_doc.upload_time.strftime('%Y-%m-%d %H:%M:%S')}")
                        
                        with detail_col2:
                            status = "Legal Document" if selected_doc.is_legal else "Non-Compliant Document"
                            st.markdown(f"**Status:** {status}")
                            st.markdown(f"**Confidence:** {selected_doc.confidence:.1f}%")
                        
                        # View extracted text
                        st.markdown("**Extracted Text:**")
                        st.text_area("", selected_doc.extracted_text, height=150, key=f"text_area_{selected_doc.id}")
                
            else:
                st.info("No documents match the selected filters.")
    
    except Exception as e:
        st.error(f"Error retrieving document history: {str(e)}")
    
    finally:
        # Close the session
        history_session.close()

# Tab 3: Statistics
with tab3:
    st.markdown("<h1 class='main-header'>Analysis Statistics</h1>", unsafe_allow_html=True)
    st.markdown("<h2 class='sub-header'>Document Analysis Insights</h2>", unsafe_allow_html=True)
    
    # Create a session for statistics
    stats_session = get_session()
    
    try:
        # Get all documents
        all_docs = stats_session.query(Document).all()
        
        if not all_docs:
            st.info("No documents have been analyzed yet. Statistics will be available after analyzing documents.")
        else:
            # Calculate statistics
            total_docs = len(all_docs)
            legal_docs = sum(1 for doc in all_docs if doc.is_legal)
            non_legal_docs = total_docs - legal_docs
            
            # Calculate by document type
            doc_types = {}
            for doc in all_docs:
                if doc.file_type in doc_types:
                    doc_types[doc.file_type] += 1
                else:
                    doc_types[doc.file_type] = 1
            
            # Display summary statistics
            st.markdown("### Summary Statistics")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Documents", total_docs)
            with col2:
                st.metric("Legal Documents", legal_docs)
            with col3:
                st.metric("Non-Compliant Documents", non_legal_docs)
            
            # Create visualizations
            st.markdown("### Visualizations")
            
            chart_col1, chart_col2 = st.columns(2)
            
            with chart_col1:
                # Legal vs. Non-Legal Distribution
                legal_data = pd.DataFrame({
                    "Category": ["Legal Documents", "Non-Compliant Documents"],
                    "Count": [legal_docs, non_legal_docs]
                })
                
                fig1 = px.pie(
                    legal_data, 
                    names="Category", 
                    values="Count",
                    title="Legal vs. Non-Compliant Distribution",
                    color="Category",
                    color_discrete_map={
                        "Legal Documents": "#10B981", 
                        "Non-Compliant Documents": "#EF4444"
                    }
                )
                fig1.update_traces(textposition='inside', textinfo='percent+label')
                st.plotly_chart(fig1, use_container_width=True)
            
            with chart_col2:
                # Document Types Distribution
                type_data = pd.DataFrame({
                    "Document Type": list(doc_types.keys()),
                    "Count": list(doc_types.values())
                })
                
                fig2 = px.bar(
                    type_data,
                    x="Document Type",
                    y="Count",
                    title="Document Types Distribution",
                    color="Document Type",
                    color_discrete_sequence=px.colors.qualitative.Set3
                )
                st.plotly_chart(fig2, use_container_width=True)
            
            # Verification Criteria Analysis
            st.markdown("### Verification Criteria Analysis")
            
            # Extract criteria results
            criteria_stats = {}
            for doc in all_docs:
                try:
                    # Convert string representation of dict to actual dict
                    criteria_dict = eval(doc.criteria_results)
                    for criterion, result in criteria_dict.items():
                        if criterion not in criteria_stats:
                            criteria_stats[criterion] = {"pass": 0, "fail": 0}
                        
                        if result:
                            criteria_stats[criterion]["pass"] += 1
                        else:
                            criteria_stats[criterion]["fail"] += 1
                except:
                    continue
            
            # Create criteria analysis data
            criteria_data = []
            for criterion, results in criteria_stats.items():
                pass_count = results["pass"]
                fail_count = results["fail"]
                total = pass_count + fail_count
                criteria_data.append({
                    "Criterion": criterion,
                    "Pass Rate": (pass_count / total) * 100 if total > 0 else 0,
                    "Pass Count": pass_count,
                    "Fail Count": fail_count
                })
            
            criteria_df = pd.DataFrame(criteria_data)
            if not criteria_df.empty:
                # Sort by pass rate
                criteria_df = criteria_df.sort_values("Pass Rate", ascending=False)
                
                # Create horizontal bar chart
                fig3 = px.bar(
                    criteria_df,
                    y="Criterion",
                    x="Pass Rate",
                    title="Criteria Pass Rate (%)",
                    orientation="h",
                    color="Pass Rate",
                    color_continuous_scale=["#EF4444", "#FBBF24", "#10B981"]
                )
                fig3.update_layout(yaxis={"categoryorder": "total ascending"})
                st.plotly_chart(fig3, use_container_width=True)
                
                # Show criteria data in table
                st.dataframe(criteria_df, use_container_width=True)
            else:
                st.info("No criteria data available yet.")
    
    except Exception as e:
        st.error(f"Error generating statistics: {str(e)}")
    
    finally:
        # Close the session
        stats_session.close()

# Add custom CSS for styling
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Poppins', sans-serif;
    }
    
    .main-header {
        font-size: 2.7rem;
        font-weight: 700;
        background: linear-gradient(90deg, #3B82F6, #7C3AED);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 1.5rem;
        text-shadow: 0px 2px 3px rgba(0,0,0,0.1);
        letter-spacing: -0.5px;
    }
    
    .sub-header {
        font-size: 1.8rem;
        font-weight: 600;
        background: linear-gradient(90deg, #1E40AF, #3B82F6);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 1rem;
        letter-spacing: -0.3px;
    }
    
    .info-box {
        background: linear-gradient(135deg, #EFF6FF 0%, #F0F7FF 100%);
        border-radius: 12px;
        padding: 25px;
        margin-bottom: 25px;
        border-left: 6px solid #4299E1;
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease;
    }
    
    .criteria-box {
        border-radius: 10px;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
        margin-bottom: 12px;
        padding: 15px;
        transition: all 0.2s ease;
    }
    
    .passed {
        background: linear-gradient(135deg, #ECFDF5 0%, #D1FAE5 100%);
        border-left: 5px solid #10B981;
    }
    
    .failed {
        background: linear-gradient(135deg, #FEF2F2 0%, #FEE2E2 100%);
        border-left: 5px solid #EF4444;
    }
    
    .document-card {
        background: linear-gradient(145deg, #FFFFFF 0%, #F8FAFC 100%);
        border-radius: 16px;
        padding: 20px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
        margin-bottom: 30px;
        transition: all 0.3s ease;
        border: 1px solid rgba(226, 232, 240, 0.8);
    }
    
    .status-badge {
        display: inline-block;
        border-radius: 20px;
        padding: 6px 12px;
        font-weight: 600;
        font-size: 0.85rem;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    
    .status-legal {
        background: linear-gradient(90deg, #059669, #10B981);
        color: white;
    }
    
    .status-illegal {
        background: linear-gradient(90deg, #DC2626, #EF4444);
        color: white;
    }
    
    .animated-element {
        animation: fadeIn 0.6s ease-in-out;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
""", unsafe_allow_html=True)